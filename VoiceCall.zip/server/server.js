// Signaling server: only introduces two phones to each other. Audio never goes through it.
// Run:  npm install ws && node server.js
const { WebSocketServer } = require('ws');
const wss = new WebSocketServer({ port: process.env.PORT || 8080 });
const users = new Map();

wss.on('connection', (ws) => {
  let myId = null;
  ws.on('message', (raw) => {
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'register') {
      myId = String(m.id);
      users.set(myId, ws);
      return;
    }
    if (!myId) return;
    const peer = users.get(String(m.to));
    if (peer && peer.readyState === 1) {
      m.from = myId;
      peer.send(JSON.stringify(m));
    } else if (m.type === 'offer') {
      ws.send(JSON.stringify({ type: 'unavailable', from: String(m.to) }));
    }
  });
  ws.on('close', () => { if (myId && users.get(myId) === ws) users.delete(myId); });
});
console.log('Signaling server on port', process.env.PORT || 8080);
