package com.example.voicecall.call

sealed class CallState {
    object Idle : CallState()
    data class Outgoing(val to: String) : CallState()
    data class Incoming(val from: String) : CallState()
    data class Active(val peer: String) : CallState()
}
