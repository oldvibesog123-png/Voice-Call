package com.example.voicecall.call

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

/** Talks to server/server.js over WebSocket. Only relays offer/answer/ice/hangup between numbers. */
class SignalingClient(
    private val url: String,
    private val myId: String,
    private val listener: Listener
) {
    interface Listener {
        fun onConnected()
        fun onError(msg: String)
        fun onMessage(type: String, from: String, data: JSONObject?)
    }

    private val http = OkHttpClient()
    private var ws: WebSocket? = null

    fun connect() {
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(JSONObject().put("type", "register").put("id", myId).toString())
                listener.onConnected()
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching {
                    val j = JSONObject(text)
                    listener.onMessage(j.getString("type"), j.optString("from"), j.optJSONObject("data"))
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                listener.onError(t.message ?: "connection failed")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                listener.onError("disconnected")
            }
        })
    }

    fun send(type: String, to: String, data: JSONObject?) {
        val m = JSONObject().put("type", type).put("to", to)
        if (data != null) m.put("data", data)
        ws?.send(m.toString())
    }

    fun close() {
        ws?.close(1000, null)
    }
}
