package com.example.voicecall

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.voicecall.call.CallEngine
import com.example.voicecall.call.CallState

class MainActivity : ComponentActivity() {
    private lateinit var engine: CallEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = CallEngine(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { App(engine) }
        }
    }

    override fun onDestroy() {
        engine.shutdown()
        super.onDestroy()
    }
}

@Composable
fun App(engine: CallEngine) {
    val state by engine.state.collectAsState()
    val online by engine.online.collectAsState()
    val notice by engine.notice.collectAsState()
    val muted by engine.muted.collectAsState()
    val speaker by engine.speaker.collectAsState()

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { perm.launch(Manifest.permission.RECORD_AUDIO) }

    var url by remember { mutableStateOf("ws://192.168.1.2:8080") }
    var myId by remember { mutableStateOf("") }
    var dial by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (!online) {
                Text("VoiceCall", fontSize = 28.sp)
                Spacer(Modifier.height(24.dp))
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("Server URL") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = myId, onValueChange = { myId = it },
                    label = { Text("Mera number (e.g. 1001)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(16.dp))
                Button(onClick = { if (myId.isNotBlank()) engine.connect(url.trim(), myId.trim()) }) {
                    Text("Connect")
                }
            } else when (val s = state) {
                is CallState.Idle -> {
                    Text("Mera number: $myId", fontSize = 16.sp)
                    Spacer(Modifier.height(24.dp))
                    OutlinedTextField(
                        value = dial, onValueChange = { dial = it },
                        label = { Text("Call karne wala number") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { engine.call(dial.trim()) }) { Text("Call") }
                }
                is CallState.Incoming -> {
                    Text("Incoming call", fontSize = 16.sp)
                    Text(s.from, fontSize = 36.sp)
                    Spacer(Modifier.height(32.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Button(
                            onClick = { engine.accept() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) { Text("Accept") }
                        Button(
                            onClick = { engine.hangup() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                        ) { Text("Reject") }
                    }
                }
                is CallState.Outgoing -> InCall("Calling ${s.to}...", muted, speaker, engine)
                is CallState.Active -> InCall("Connected: ${s.peer}", muted, speaker, engine)
            }
            notice?.let {
                Spacer(Modifier.height(24.dp))
                Text(it, fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun InCall(label: String, muted: Boolean, speaker: Boolean, engine: CallEngine) {
    Text(label, fontSize = 26.sp)
    Spacer(Modifier.height(32.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = { engine.setMuted(!muted) }) { Text(if (muted) "Unmute" else "Mute") }
        OutlinedButton(onClick = { engine.setSpeaker(!speaker) }) { Text(if (speaker) "Earpiece" else "Speaker") }
    }
    Spacer(Modifier.height(24.dp))
    Button(
        onClick = { engine.hangup() },
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
    ) { Text("End call") }
}
