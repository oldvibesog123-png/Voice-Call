package com.example.voicecall.audio

/**
 * Voice effect hook (STEP 2: noise gate, pitch shift, formant shift go here).
 * Frame = 16-bit mono PCM, modify in place.
 */
interface VoiceProcessor {
    fun process(frame: ShortArray, sampleRate: Int)
}

class PassThroughProcessor : VoiceProcessor {
    override fun process(frame: ShortArray, sampleRate: Int) {}
}
