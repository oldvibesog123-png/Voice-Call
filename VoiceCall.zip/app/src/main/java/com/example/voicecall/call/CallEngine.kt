package com.example.voicecall.call

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.example.voicecall.audio.PassThroughProcessor
import com.example.voicecall.audio.VoiceProcessor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule
import java.util.concurrent.CopyOnWriteArrayList

open class SimpleSdp : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

/** All call logic lives here. UI only watches the StateFlows and calls the public functions. */
class CallEngine(private val app: Context) : SignalingClient.Listener {

    private val _state = MutableStateFlow<CallState>(CallState.Idle)
    val state: StateFlow<CallState> = _state
    private val _online = MutableStateFlow(false)
    val online: StateFlow<Boolean> = _online
    private val _notice = MutableStateFlow<String?>(null)
    val notice: StateFlow<String?> = _notice
    private val _muted = MutableStateFlow(false)
    val muted: StateFlow<Boolean> = _muted
    private val _speaker = MutableStateFlow(false)
    val speaker: StateFlow<Boolean> = _speaker

    /** STEP 2 will connect this to the mic stream. Not wired yet. */
    var voiceProcessor: VoiceProcessor = PassThroughProcessor()

    private val main = Handler(Looper.getMainLooper())
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var signaling: SignalingClient? = null
    private var factory: PeerConnectionFactory? = null
    private var pc: PeerConnection? = null
    private var source: AudioSource? = null
    private var track: AudioTrack? = null
    private var peerId = ""
    private var pendingOffer: String? = null
    private val pendingIce = CopyOnWriteArrayList<IceCandidate>()

    // STUN only. For calls over mobile data on both sides you will also need a TURN server.
    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()
    )

    // ---------- public API ----------

    fun connect(url: String, myId: String) {
        _notice.value = null
        if (factory == null) {
            PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(app).createInitializationOptions()
            )
            val adm = JavaAudioDeviceModule.builder(app)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule()
            factory = PeerConnectionFactory.builder().setAudioDeviceModule(adm).createPeerConnectionFactory()
        }
        signaling?.close()
        signaling = SignalingClient(url, myId, this).also { it.connect() }
    }

    fun call(to: String) {
        if (_state.value != CallState.Idle || to.isBlank()) return
        peerId = to
        _state.value = CallState.Outgoing(to)
        createPc()
        val mc = MediaConstraints().apply {
            mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "true"))
        }
        pc?.createOffer(object : SimpleSdp() {
            override fun onCreateSuccess(d: SessionDescription) {
                pc?.setLocalDescription(SimpleSdp(), d)
                signaling?.send("offer", to, JSONObject().put("sdp", d.description))
            }
        }, mc)
    }

    fun accept() {
        val sdp = pendingOffer ?: return
        createPc()
        setRemote(SessionDescription.Type.OFFER, sdp) {
            pc?.createAnswer(object : SimpleSdp() {
                override fun onCreateSuccess(d: SessionDescription) {
                    pc?.setLocalDescription(SimpleSdp(), d)
                    signaling?.send("answer", peerId, JSONObject().put("sdp", d.description))
                    _state.value = CallState.Active(peerId)
                }
            }, MediaConstraints())
        }
    }

    fun hangup() {
        if (peerId.isNotEmpty()) signaling?.send("hangup", peerId, null)
        cleanup()
    }

    fun setMuted(m: Boolean) {
        _muted.value = m
        track?.setEnabled(!m)
    }

    fun setSpeaker(on: Boolean) {
        _speaker.value = on
        audio.isSpeakerphoneOn = on
    }

    fun shutdown() {
        signaling?.close()
        cleanup()
    }

    // ---------- signaling callbacks ----------

    override fun onConnected() {
        _online.value = true
    }

    override fun onError(msg: String) {
        _online.value = false
        _notice.value = "Server: $msg"
        cleanup()
    }

    override fun onMessage(type: String, from: String, data: JSONObject?) {
        when (type) {
            "offer" -> {
                if (_state.value != CallState.Idle) {
                    signaling?.send("busy", from, null)
                } else {
                    peerId = from
                    pendingOffer = data?.optString("sdp")
                    _state.value = CallState.Incoming(from)
                }
            }
            "answer" -> {
                val sdp = data?.optString("sdp") ?: return
                setRemote(SessionDescription.Type.ANSWER, sdp) { _state.value = CallState.Active(from) }
            }
            "ice" -> {
                val d = data ?: return
                addIce(IceCandidate(d.optString("sdpMid"), d.optInt("sdpMLineIndex"), d.optString("sdp")))
            }
            "hangup" -> if (from == peerId) {
                _notice.value = "Call ended"
                cleanup()
            }
            "busy" -> {
                _notice.value = "User is busy"
                cleanup()
            }
            "unavailable" -> {
                _notice.value = "Number is offline"
                cleanup()
            }
        }
    }

    // ---------- WebRTC internals ----------

    private fun createPc() {
        val f = factory ?: return
        audio.mode = AudioManager.MODE_IN_COMMUNICATION
        audio.isSpeakerphoneOn = _speaker.value
        val cfg = PeerConnection.RTCConfiguration(iceServers).apply {
            sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        }
        pc = f.createPeerConnection(cfg, object : PeerConnection.Observer {
            override fun onIceCandidate(c: IceCandidate) {
                signaling?.send(
                    "ice", peerId,
                    JSONObject().put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex).put("sdp", c.sdp)
                )
            }

            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState) {
                if (s == PeerConnection.IceConnectionState.FAILED ||
                    s == PeerConnection.IceConnectionState.CLOSED
                ) {
                    _notice.value = "Connection lost"
                    cleanup()
                }
            }

            override fun onSignalingChange(s: PeerConnection.SignalingState) {}
            override fun onIceConnectionReceivingChange(b: Boolean) {}
            override fun onIceGatheringChange(s: PeerConnection.IceGatheringState) {}
            override fun onIceCandidatesRemoved(c: Array<out IceCandidate>) {}
            override fun onAddStream(s: MediaStream) {}
            override fun onRemoveStream(s: MediaStream) {}
            override fun onDataChannel(d: DataChannel) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(r: RtpReceiver, s: Array<out MediaStream>) {}
        })
        source = f.createAudioSource(MediaConstraints())
        track = f.createAudioTrack("a0", source).apply { setEnabled(!_muted.value) }
        pc?.addTrack(track, listOf("s0"))
    }

    private fun setRemote(type: SessionDescription.Type, sdp: String, done: () -> Unit) {
        pc?.setRemoteDescription(object : SimpleSdp() {
            override fun onSetSuccess() {
                pendingIce.forEach { pc?.addIceCandidate(it) }
                pendingIce.clear()
                done()
            }
        }, SessionDescription(type, sdp))
    }

    private fun addIce(c: IceCandidate) {
        val p = pc
        if (p != null && p.remoteDescription != null) p.addIceCandidate(c) else pendingIce.add(c)
    }

    private fun cleanup() {
        main.post {
            pc?.close()
            pc?.dispose()
            pc = null
            track?.dispose(); track = null
            source?.dispose(); source = null
            pendingIce.clear()
            pendingOffer = null
            peerId = ""
            audio.mode = AudioManager.MODE_NORMAL
            audio.isSpeakerphoneOn = false
            _state.value = CallState.Idle
        }
    }
}
